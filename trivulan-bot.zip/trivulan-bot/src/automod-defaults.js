// A short, conservative default list. Every server can extend this for free
// (see /automod addword) but the base list ships with the bot so moderation
// works the moment Trivulan joins.
const DEFAULT_BANNED_WORDS = ["nigger", "faggot", "retard"];

const INVITE_LINK_REGEX = /(discord\.gg|discord(app)?\.com\/invite)\/[a-z0-9-]+/i;

module.exports = { DEFAULT_BANNED_WORDS, INVITE_LINK_REGEX };
