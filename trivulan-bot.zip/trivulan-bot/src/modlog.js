const db = require("./db");

// If the server has set a mod-log channel, mirror moderation events into it.
async function logToModChannel(guild, message) {
  const settings = db.getGuild(guild.id);
  if (!settings.modLogChannelId) return;

  const channel = await guild.channels.fetch(settings.modLogChannelId).catch(() => null);
  if (!channel || !channel.isTextBased()) return;

  await channel.send(message).catch(() => {});
}

module.exports = { logToModChannel };
