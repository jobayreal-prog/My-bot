// Trivulan's storage layer.
//
// This is intentionally a plain JSON file instead of a "real" database like
// Postgres or SQLite. It needs zero setup and zero native compilation, which
// matters a lot for a first deploy. The tradeoff: on some hosts the file can
// reset when you redeploy. See the README for how to upgrade later if you
// outgrow this.

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "data", "db.json");

function defaultData() {
  return { guilds: {} };
}

function load() {
  try {
    const raw = fs.readFileSync(DB_PATH, "utf8");
    return JSON.parse(raw);
  } catch (err) {
    return defaultData();
  }
}

function save(data) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function ensureGuild(data, guildId) {
  if (!data.guilds[guildId]) {
    data.guilds[guildId] = {
      modLogChannelId: null,
      antiRaid: false,
      warnThreshold: null,
      customBannedWords: [],
      warns: {},
      autoRoleId: null,
      welcome: { channelId: null, message: null },
      goodbye: { channelId: null, message: null },
      starboard: { channelId: null, threshold: 3, posts: {} },
      levels: {}, // userId -> { xp, level }
      economy: {}, // userId -> { coins, lastDaily }
      tickets: { supportRoleId: null, openTickets: {} } // channelId -> userId
    };
  }
  return data.guilds[guildId];
}

// ---- Public API ----

function getGuild(guildId) {
  const data = load();
  return ensureGuild(data, guildId);
}

function setModLogChannel(guildId, channelId) {
  const data = load();
  ensureGuild(data, guildId).modLogChannelId = channelId;
  save(data);
}

function setAntiRaid(guildId, enabled) {
  const data = load();
  ensureGuild(data, guildId).antiRaid = enabled;
  save(data);
}

function setWarnThreshold(guildId, count) {
  const data = load();
  ensureGuild(data, guildId).warnThreshold = count;
  save(data);
}

function addBannedWord(guildId, word) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  word = word.toLowerCase();
  if (!guild.customBannedWords.includes(word)) guild.customBannedWords.push(word);
  save(data);
  return guild.customBannedWords;
}

function removeBannedWord(guildId, word) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  word = word.toLowerCase();
  guild.customBannedWords = guild.customBannedWords.filter((w) => w !== word);
  save(data);
  return guild.customBannedWords;
}

function addWarn(guildId, userId, { reason, moderator }) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  if (!guild.warns[userId]) guild.warns[userId] = [];
  guild.warns[userId].push({ reason, moderator, date: new Date().toISOString() });
  save(data);
  return guild.warns[userId];
}

function getWarns(guildId, userId) {
  return getGuild(guildId).warns[userId] || [];
}

function clearWarns(guildId, userId) {
  const data = load();
  ensureGuild(data, guildId).warns[userId] = [];
  save(data);
}

// ---- Auto-role ----

function setAutoRole(guildId, roleId) {
  const data = load();
  ensureGuild(data, guildId).autoRoleId = roleId;
  save(data);
}

// ---- Welcome / goodbye ----

function setWelcome(guildId, { channelId, message }) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  if (channelId !== undefined) guild.welcome.channelId = channelId;
  if (message !== undefined) guild.welcome.message = message;
  save(data);
}

function setGoodbye(guildId, { channelId, message }) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  if (channelId !== undefined) guild.goodbye.channelId = channelId;
  if (message !== undefined) guild.goodbye.message = message;
  save(data);
}

// ---- Starboard ----

function setStarboard(guildId, { channelId, threshold }) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  if (channelId !== undefined) guild.starboard.channelId = channelId;
  if (threshold !== undefined) guild.starboard.threshold = threshold;
  save(data);
}

function getStarboardPost(guildId, originalMessageId) {
  return getGuild(guildId).starboard.posts[originalMessageId] || null;
}

function setStarboardPost(guildId, originalMessageId, starboardMessageId) {
  const data = load();
  ensureGuild(data, guildId).starboard.posts[originalMessageId] = starboardMessageId;
  save(data);
}

// ---- Leveling ----

function levelForXp(xp) {
  return Math.floor(xp / 100);
}

function addXp(guildId, userId, amount) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  if (!guild.levels[userId]) guild.levels[userId] = { xp: 0 };
  const before = levelForXp(guild.levels[userId].xp);
  guild.levels[userId].xp += amount;
  const after = levelForXp(guild.levels[userId].xp);
  save(data);
  return { xp: guild.levels[userId].xp, level: after, leveledUp: after > before };
}

function getLevel(guildId, userId) {
  const guild = getGuild(guildId);
  const xp = guild.levels[userId]?.xp || 0;
  return { xp, level: levelForXp(xp) };
}

function getLeaderboard(guildId, limit = 10) {
  const guild = getGuild(guildId);
  return Object.entries(guild.levels)
    .map(([userId, data]) => ({ userId, xp: data.xp, level: levelForXp(data.xp) }))
    .sort((a, b) => b.xp - a.xp)
    .slice(0, limit);
}

// ---- Economy ----

function getEconomy(guildId, userId) {
  const guild = getGuild(guildId);
  return guild.economy[userId] || { coins: 0, lastDaily: null };
}

function addCoins(guildId, userId, amount) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  if (!guild.economy[userId]) guild.economy[userId] = { coins: 0, lastDaily: null };
  guild.economy[userId].coins = Math.max(0, guild.economy[userId].coins + amount);
  save(data);
  return guild.economy[userId].coins;
}

function claimDaily(guildId, userId, amount) {
  const data = load();
  const guild = ensureGuild(data, guildId);
  if (!guild.economy[userId]) guild.economy[userId] = { coins: 0, lastDaily: null };
  const entry = guild.economy[userId];
  const now = Date.now();
  const cooldownMs = 24 * 60 * 60 * 1000;

  if (entry.lastDaily && now - entry.lastDaily < cooldownMs) {
    return { claimed: false, msRemaining: cooldownMs - (now - entry.lastDaily) };
  }

  entry.coins += amount;
  entry.lastDaily = now;
  save(data);
  return { claimed: true, coins: entry.coins };
}

// ---- Tickets ----

function setTicketSupportRole(guildId, roleId) {
  const data = load();
  ensureGuild(data, guildId).tickets.supportRoleId = roleId;
  save(data);
}

function openTicket(guildId, channelId, userId) {
  const data = load();
  ensureGuild(data, guildId).tickets.openTickets[channelId] = userId;
  save(data);
}

function closeTicket(guildId, channelId) {
  const data = load();
  delete ensureGuild(data, guildId).tickets.openTickets[channelId];
  save(data);
}

function getTicketOwner(guildId, channelId) {
  return getGuild(guildId).tickets.openTickets[channelId] || null;
}

module.exports = {
  getGuild,
  setModLogChannel,
  setAntiRaid,
  setWarnThreshold,
  addBannedWord,
  removeBannedWord,
  addWarn,
  getWarns,
  clearWarns,
  setAutoRole,
  setWelcome,
  setGoodbye,
  setStarboard,
  getStarboardPost,
  setStarboardPost,
  addXp,
  getLevel,
  getLeaderboard,
  getEconomy,
  addCoins,
  claimDaily,
  setTicketSupportRole,
  openTicket,
  closeTicket,
  getTicketOwner
};
