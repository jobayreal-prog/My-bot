const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("See a member's warning history")
    .addUserOption((opt) => opt.setName("user").setDescription("Whose warnings to view").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const warns = db.getWarns(interaction.guild.id, target.id);

    if (warns.length === 0) {
      return interaction.reply({ content: `**${target.tag}** has no warnings.`, ephemeral: true });
    }

    const list = warns
      .map((w, i) => `**${i + 1}.** ${w.reason} — by ${w.moderator} on ${new Date(w.date).toLocaleDateString()}`)
      .join("\n");

    await interaction.reply({ content: `**${target.tag}**'s warnings:\n${list}`, ephemeral: true });
  }
};
