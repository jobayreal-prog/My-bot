const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../db");
const { logToModChannel } = require("../../modlog");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a member")
    .addUserOption((opt) => opt.setName("user").setDescription("Who to warn").setRequired(true))
    .addStringOption((opt) => opt.setName("reason").setDescription("Why are they being warned?").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason");

    const warns = db.addWarn(interaction.guild.id, target.id, {
      reason,
      moderator: interaction.user.tag
    });

    await interaction.reply(`⚠️ **${target.tag}** was warned (${warns.length} total). Reason: ${reason}`);
    await logToModChannel(interaction.guild, `⚠️ ${target.tag} warned by ${interaction.user.tag}: ${reason}`);

    // If the server set a warn threshold and this member just hit it,
    // time them out automatically.
    const guildSettings = db.getGuild(interaction.guild.id);
    if (guildSettings.warnThreshold && warns.length >= guildSettings.warnThreshold) {
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      if (member && member.moderatable) {
        await member.timeout(60 * 60 * 1000, "Auto-timeout: warn threshold reached");
        await interaction.followUp(
          `🚨 **${target.tag}** hit the warn threshold (${guildSettings.warnThreshold}) and was auto-timed-out for 1 hour.`
        );
      }
    }
  }
};
