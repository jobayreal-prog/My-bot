const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Timeout (mute) a member for a number of minutes")
    .addUserOption((opt) => opt.setName("user").setDescription("Who to timeout").setRequired(true))
    .addIntegerOption((opt) =>
      opt.setName("minutes").setDescription("Timeout length in minutes (max 40320 / 28 days)").setRequired(true)
    )
    .addStringOption((opt) => opt.setName("reason").setDescription("Why are they being timed out?"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const minutes = interaction.options.getInteger("minutes");
    const reason = interaction.options.getString("reason") || "No reason provided";

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) {
      return interaction.reply({ content: "That user isn't in this server.", ephemeral: true });
    }
    if (!member.moderatable) {
      return interaction.reply({
        content: "I can't timeout that member - check my role is above theirs.",
        ephemeral: true
      });
    }

    const ms = Math.min(minutes, 40320) * 60 * 1000;
    await member.timeout(ms, reason);
    await interaction.reply(`🔇 **${target.tag}** was timed out for ${minutes} minute(s). Reason: ${reason}`);
  }
};
