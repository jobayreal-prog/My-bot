const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("clearwarns")
    .setDescription("Clear all warnings for a member")
    .addUserOption((opt) => opt.setName("user").setDescription("Whose warnings to clear").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    db.clearWarns(interaction.guild.id, target.id);
    await interaction.reply(`🧹 Cleared all warnings for **${target.tag}**.`);
  }
};
