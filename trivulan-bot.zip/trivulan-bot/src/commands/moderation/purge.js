const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("purge")
    .setDescription("Bulk delete recent messages in this channel")
    .addIntegerOption((opt) =>
      opt.setName("count").setDescription("How many messages to delete (1-100)").setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const count = Math.max(1, Math.min(100, interaction.options.getInteger("count")));
    await interaction.deferReply({ ephemeral: true });
    const deleted = await interaction.channel.bulkDelete(count, true).catch(() => null);
    if (!deleted) {
      return interaction.editReply("I couldn't delete those messages - they may be older than 14 days.");
    }
    await interaction.editReply(`🧹 Deleted ${deleted.size} message(s).`);
  }
};
