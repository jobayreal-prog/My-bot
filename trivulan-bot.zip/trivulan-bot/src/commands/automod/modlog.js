const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("modlog")
    .setDescription("Set the channel Trivulan posts moderation activity to")
    .addChannelOption((opt) =>
      opt
        .setName("channel")
        .setDescription("Text channel to log to")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const channel = interaction.options.getChannel("channel");
    db.setModLogChannel(interaction.guild.id, channel.id);
    await interaction.reply(`📋 Mod-log channel set to ${channel}.`);
  }
};
