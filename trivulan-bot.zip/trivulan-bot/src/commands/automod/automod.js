const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("automod")
    .setDescription("Manage Trivulan's custom word filter")
    .addSubcommand((sub) =>
      sub
        .setName("addword")
        .setDescription("Block an extra word or phrase")
        .addStringOption((opt) => opt.setName("word").setDescription("Word or phrase to block").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("removeword")
        .setDescription("Unblock a word or phrase")
        .addStringOption((opt) => opt.setName("word").setDescription("Word or phrase to remove").setRequired(true))
    )
    .addSubcommand((sub) => sub.setName("list").setDescription("List your server's custom blocked words"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === "addword") {
      const word = interaction.options.getString("word");
      const list = db.addBannedWord(interaction.guild.id, word);
      return interaction.reply({ content: `Added **${word}** to the filter. (${list.length} custom words total)`, ephemeral: true });
    }

    if (sub === "removeword") {
      const word = interaction.options.getString("word");
      const list = db.removeBannedWord(interaction.guild.id, word);
      return interaction.reply({ content: `Removed **${word}** from the filter. (${list.length} custom words remaining)`, ephemeral: true });
    }

    if (sub === "list") {
      const settings = db.getGuild(interaction.guild.id);
      const words = settings.customBannedWords;
      return interaction.reply({
        content: words.length ? `Custom blocked words: ${words.join(", ")}` : "No custom words added yet.",
        ephemeral: true
      });
    }
  }
};
