const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warnthreshold")
    .setDescription("Auto-timeout a member once they reach this many warnings")
    .addIntegerOption((opt) =>
      opt.setName("count").setDescription("Number of warnings that triggers an auto-timeout (0 to disable)").setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const count = interaction.options.getInteger("count");
    db.setWarnThreshold(interaction.guild.id, count > 0 ? count : null);
    await interaction.reply(
      count > 0
        ? `🚨 Members will now be auto-timed-out after **${count}** warnings.`
        : `Auto-timeout on warnings is now disabled.`
    );
  }
};
