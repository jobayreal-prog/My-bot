const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("antiraid")
    .setDescription("Turn Trivulan's anti-raid join protection on or off")
    .addBooleanOption((opt) => opt.setName("enabled").setDescription("Turn it on or off").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const enabled = interaction.options.getBoolean("enabled");
    db.setAntiRaid(interaction.guild.id, enabled);
    await interaction.reply(`🛡️ Anti-raid is now **${enabled ? "ON" : "OFF"}** for this server.`);
  }
};
