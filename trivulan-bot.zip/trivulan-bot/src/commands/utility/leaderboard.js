const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder().setName("leaderboard").setDescription("See this server's top members by XP"),

  async execute(interaction) {
    const top = db.getLeaderboard(interaction.guild.id, 10);

    if (top.length === 0) {
      return interaction.reply({ content: "No one has earned XP yet - start chatting!", ephemeral: true });
    }

    const lines = top.map((entry, i) => `**${i + 1}.** <@${entry.userId}> - Level ${entry.level} (${entry.xp} XP)`);

    const embed = new EmbedBuilder()
      .setColor(0xe3b341)
      .setTitle(`🏆 ${interaction.guild.name} Leaderboard`)
      .setDescription(lines.join("\n"));

    await interaction.reply({ embeds: [embed] });
  }
};
