const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Set up a support ticket system")
    .addSubcommand((sub) =>
      sub
        .setName("setup")
        .setDescription("Set which role can see new tickets")
        .addRoleOption((opt) => opt.setName("support_role").setDescription("Role that can view tickets").setRequired(true))
    )
    .addSubcommand((sub) => sub.setName("panel").setDescription("Post the 'Open a Ticket' button in this channel"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === "setup") {
      const role = interaction.options.getRole("support_role");
      db.setTicketSupportRole(interaction.guild.id, role.id);
      return interaction.reply(`✅ ${role} can now see new tickets.`);
    }

    if (sub === "panel") {
      const embed = new EmbedBuilder()
        .setColor(0x5b8dbe)
        .setTitle("Need help?")
        .setDescription("Click below to open a private ticket with the team.");

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("ticket_open").setLabel("Open a Ticket").setStyle(ButtonStyle.Primary).setEmoji("🎫")
      );

      await interaction.channel.send({ embeds: [embed], components: [row] });
      await interaction.reply({ content: "Panel posted.", ephemeral: true });
    }
  }
};
