const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("goodbye")
    .setDescription("Configure the message Trivulan posts when someone leaves")
    .addSubcommand((sub) =>
      sub
        .setName("channel")
        .setDescription("Set the goodbye channel")
        .addChannelOption((opt) =>
          opt.setName("channel").setDescription("Channel to post in").addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("message")
        .setDescription("Set the goodbye message text")
        .addStringOption((opt) =>
          opt
            .setName("text")
            .setDescription("Use {user}, {username}, {server}, {membercount} as placeholders")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) => sub.setName("off").setDescription("Turn off goodbye messages"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === "channel") {
      const channel = interaction.options.getChannel("channel");
      db.setGoodbye(interaction.guild.id, { channelId: channel.id });
      return interaction.reply(`✅ Goodbye messages will post in ${channel}.`);
    }

    if (sub === "message") {
      const text = interaction.options.getString("text");
      db.setGoodbye(interaction.guild.id, { message: text });
      return interaction.reply(`✅ Goodbye message set to:\n${text}`);
    }

    if (sub === "off") {
      db.setGoodbye(interaction.guild.id, { channelId: null, message: null });
      return interaction.reply("Goodbye messages are off.");
    }
  }
};
