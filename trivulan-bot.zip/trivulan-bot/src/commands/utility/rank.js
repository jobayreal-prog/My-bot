const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("rank")
    .setDescription("See your (or someone's) level and XP")
    .addUserOption((opt) => opt.setName("user").setDescription("Whose rank to check")),

  async execute(interaction) {
    const target = interaction.options.getUser("user") || interaction.user;
    const { xp, level } = db.getLevel(interaction.guild.id, target.id);
    const xpIntoLevel = xp % 100;

    const embed = new EmbedBuilder()
      .setColor(0x5b8dbe)
      .setAuthor({ name: target.tag, iconURL: target.displayAvatarURL() })
      .addFields(
        { name: "Level", value: String(level), inline: true },
        { name: "Total XP", value: String(xp), inline: true },
        { name: "Progress", value: `${xpIntoLevel}/100 to next level`, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
