const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("autorole")
    .setDescription("Automatically give new members a role when they join")
    .addRoleOption((opt) => opt.setName("role").setDescription("Role to auto-assign (omit to disable)"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const role = interaction.options.getRole("role");
    db.setAutoRole(interaction.guild.id, role ? role.id : null);
    await interaction.reply(role ? `✅ New members will automatically get ${role}.` : "Auto-role disabled.");
  }
};
