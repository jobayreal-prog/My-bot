const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("lockdown")
    .setDescription("Lock or unlock this channel for @everyone")
    .addBooleanOption((opt) => opt.setName("locked").setDescription("true to lock, false to unlock").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const locked = interaction.options.getBoolean("locked");
    const everyone = interaction.guild.roles.everyone;

    await interaction.channel.permissionOverwrites.edit(everyone, {
      SendMessages: locked ? false : null
    });

    await interaction.reply(locked ? "🔒 Channel locked - @everyone can no longer send messages." : "🔓 Channel unlocked.");
  }
};
