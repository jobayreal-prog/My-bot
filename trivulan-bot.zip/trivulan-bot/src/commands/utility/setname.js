const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("setname")
    .setDescription("Give Trivulan a custom nickname in this server")
    .addStringOption((opt) =>
      opt.setName("name").setDescription("New nickname (1-32 characters)").setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const name = interaction.options.getString("name").slice(0, 32);
    const me = interaction.guild.members.me;

    if (!me.permissions.has(PermissionFlagsBits.ChangeNickname)) {
      return interaction.reply({
        content: "I need the **Change Nickname** permission to do that.",
        ephemeral: true
      });
    }

    await me.setNickname(name).catch(() => null);
    await interaction.reply(`Done - I'll go by **${name}** in this server from now on.`);
  }
};
