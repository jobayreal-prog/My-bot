const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("starboard")
    .setDescription("Repost popular messages to a starboard channel")
    .addSubcommand((sub) =>
      sub
        .setName("setup")
        .setDescription("Set the starboard channel and star threshold")
        .addChannelOption((opt) =>
          opt.setName("channel").setDescription("Channel to post starred messages in").addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
        .addIntegerOption((opt) => opt.setName("threshold").setDescription("Stars needed to post (default 3)"))
    )
    .addSubcommand((sub) => sub.setName("off").setDescription("Turn off the starboard"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === "setup") {
      const channel = interaction.options.getChannel("channel");
      const threshold = interaction.options.getInteger("threshold") || 3;
      db.setStarboard(interaction.guild.id, { channelId: channel.id, threshold });
      return interaction.reply(`⭐ Starboard set to ${channel} - messages need **${threshold}** stars to post.`);
    }

    if (sub === "off") {
      db.setStarboard(interaction.guild.id, { channelId: null });
      return interaction.reply("Starboard is off.");
    }
  }
};
