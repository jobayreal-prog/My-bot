const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("welcome")
    .setDescription("Configure the message Trivulan posts when someone joins")
    .addSubcommand((sub) =>
      sub
        .setName("channel")
        .setDescription("Set the welcome channel")
        .addChannelOption((opt) =>
          opt.setName("channel").setDescription("Channel to post in").addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("message")
        .setDescription("Set the welcome message text")
        .addStringOption((opt) =>
          opt
            .setName("text")
            .setDescription("Use {user}, {username}, {server}, {membercount} as placeholders")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) => sub.setName("off").setDescription("Turn off welcome messages"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === "channel") {
      const channel = interaction.options.getChannel("channel");
      db.setWelcome(interaction.guild.id, { channelId: channel.id });
      return interaction.reply(`✅ Welcome messages will post in ${channel}.`);
    }

    if (sub === "message") {
      const text = interaction.options.getString("text");
      db.setWelcome(interaction.guild.id, { message: text });
      return interaction.reply(`✅ Welcome message set to:\n${text}`);
    }

    if (sub === "off") {
      db.setWelcome(interaction.guild.id, { channelId: null, message: null });
      return interaction.reply("Welcome messages are off.");
    }
  }
};
