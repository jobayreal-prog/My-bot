const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

const CHOICES = ["rock", "paper", "scissors"];
const BEATS = { rock: "scissors", paper: "rock", scissors: "paper" };
const EMOJI = { rock: "🪨", paper: "📄", scissors: "✂️" };

module.exports = {
  data: new SlashCommandBuilder().setName("rps").setDescription("Play rock-paper-scissors against Trivulan"),

  async execute(interaction) {
    const row = new ActionRowBuilder().addComponents(
      CHOICES.map((choice) =>
        new ButtonBuilder()
          .setCustomId(`rps:${choice}:${interaction.user.id}`)
          .setLabel(`${EMOJI[choice]} ${choice}`)
          .setStyle(ButtonStyle.Secondary)
      )
    );

    const reply = await interaction.reply({ content: "Pick your move:", components: [row], fetchReply: true });

    const collector = reply.createMessageComponentCollector({ time: 15000, max: 1 });

    collector.on("collect", async (buttonInteraction) => {
      const [, playerChoice, requesterId] = buttonInteraction.customId.split(":");
      if (buttonInteraction.user.id !== requesterId) {
        return buttonInteraction.reply({ content: "This isn't your game - run `/rps` yourself!", ephemeral: true });
      }

      const botChoice = CHOICES[Math.floor(Math.random() * CHOICES.length)];
      let outcome;
      if (playerChoice === botChoice) outcome = "It's a tie!";
      else if (BEATS[playerChoice] === botChoice) outcome = "You win! 🎉";
      else outcome = "I win! 😎";

      await buttonInteraction.update({
        content: `You picked ${EMOJI[playerChoice]} **${playerChoice}**, I picked ${EMOJI[botChoice]} **${botChoice}**. ${outcome}`,
        components: []
      });
    });

    collector.on("end", async (collected) => {
      if (collected.size === 0) {
        await interaction.editReply({ content: "No answer in time - game over.", components: [] }).catch(() => {});
      }
    });
  }
};
