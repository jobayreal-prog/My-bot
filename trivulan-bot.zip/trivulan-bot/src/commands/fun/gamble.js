const { SlashCommandBuilder } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("gamble")
    .setDescription("Bet coins on a coinflip - double or nothing")
    .addIntegerOption((opt) => opt.setName("amount").setDescription("How many coins to bet").setRequired(true)),

  async execute(interaction) {
    const amount = interaction.options.getInteger("amount");
    if (amount <= 0) {
      return interaction.reply({ content: "Bet at least 1 coin.", ephemeral: true });
    }

    const { coins } = db.getEconomy(interaction.guild.id, interaction.user.id);
    if (amount > coins) {
      return interaction.reply({ content: `You only have **${coins}** coins.`, ephemeral: true });
    }

    const won = Math.random() < 0.5;
    const newBalance = db.addCoins(interaction.guild.id, interaction.user.id, won ? amount : -amount);

    await interaction.reply(
      won
        ? `🪙 It landed in your favor! You won **${amount}** coins. Balance: **${newBalance}**.`
        : `🪙 Not this time - you lost **${amount}** coins. Balance: **${newBalance}**.`
    );
  }
};
