const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

const QUESTIONS = [
  { q: "What planet is known as the Red Planet?", options: ["Venus", "Mars", "Jupiter", "Saturn"], answer: 1 },
  { q: "How many strings does a standard guitar have?", options: ["4", "5", "6", "7"], answer: 2 },
  { q: "What's the largest ocean on Earth?", options: ["Atlantic", "Indian", "Arctic", "Pacific"], answer: 3 },
  { q: "In what year did Discord launch?", options: ["2013", "2015", "2017", "2019"], answer: 1 },
  { q: "What's the chemical symbol for gold?", options: ["Ag", "Gd", "Au", "Go"], answer: 2 },
  { q: "How many sides does a hexagon have?", options: ["5", "6", "7", "8"], answer: 1 }
];

module.exports = {
  data: new SlashCommandBuilder().setName("trivia").setDescription("Answer a random trivia question"),

  async execute(interaction) {
    const question = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];

    const row = new ActionRowBuilder().addComponents(
      question.options.map((opt, i) =>
        new ButtonBuilder()
          .setCustomId(`trivia:${i}:${question.answer}:${interaction.user.id}`)
          .setLabel(opt)
          .setStyle(ButtonStyle.Primary)
      )
    );

    const reply = await interaction.reply({ content: `🧠 **${question.q}**`, components: [row], fetchReply: true });
    const collector = reply.createMessageComponentCollector({ time: 15000, max: 1 });

    collector.on("collect", async (buttonInteraction) => {
      const [, chosenIndex, correctIndex, requesterId] = buttonInteraction.customId.split(":");
      if (buttonInteraction.user.id !== requesterId) {
        return buttonInteraction.reply({ content: "This isn't your question - run `/trivia` yourself!", ephemeral: true });
      }

      const correct = chosenIndex === correctIndex;
      await buttonInteraction.update({
        content: `${question.q}\n${correct ? "✅ Correct!" : `❌ Not quite - the answer was **${question.options[correctIndex]}**.`}`,
        components: []
      });
    });

    collector.on("end", async (collected) => {
      if (collected.size === 0) {
        await interaction.editReply({
          content: `${question.q}\n⏰ Time's up - the answer was **${question.options[question.answer]}**.`,
          components: []
        }).catch(() => {});
      }
    });
  }
};
