const { SlashCommandBuilder } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder().setName("daily").setDescription("Claim your daily coins"),

  async execute(interaction) {
    const amount = 50 + Math.floor(Math.random() * 101); // 50-150
    const result = db.claimDaily(interaction.guild.id, interaction.user.id, amount);

    if (!result.claimed) {
      const hours = Math.floor(result.msRemaining / (1000 * 60 * 60));
      const minutes = Math.floor((result.msRemaining % (1000 * 60 * 60)) / (1000 * 60));
      return interaction.reply({
        content: `⏳ You already claimed today. Come back in ${hours}h ${minutes}m.`,
        ephemeral: true
      });
    }

    await interaction.reply(`💰 You claimed **${amount} coins**! Balance: **${result.coins}**.`);
  }
};
