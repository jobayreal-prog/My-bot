const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("roll")
    .setDescription("Roll dice, e.g. 2d6")
    .addStringOption((opt) =>
      opt.setName("dice").setDescription("Format: NdM, like 2d6 or 1d20").setRequired(false)
    ),

  async execute(interaction) {
    const input = interaction.options.getString("dice") || "1d20";
    const match = input.match(/^(\d{1,2})d(\d{1,4})$/i);

    if (!match) {
      return interaction.reply({ content: "Use the format `NdM`, like `2d6` or `1d20`.", ephemeral: true });
    }

    const count = Math.min(parseInt(match[1], 10), 20);
    const sides = Math.min(parseInt(match[2], 10), 1000);
    const rolls = Array.from({ length: count }, () => 1 + Math.floor(Math.random() * sides));
    const total = rolls.reduce((a, b) => a + b, 0);

    await interaction.reply(`🎲 Rolling **${count}d${sides}**: [${rolls.join(", ")}] → total **${total}**`);
  }
};
