const { SlashCommandBuilder } = require("discord.js");
const db = require("../../db");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Check your (or someone's) coin balance")
    .addUserOption((opt) => opt.setName("user").setDescription("Whose balance to check")),

  async execute(interaction) {
    const target = interaction.options.getUser("user") || interaction.user;
    const { coins } = db.getEconomy(interaction.guild.id, target.id);
    await interaction.reply(`💰 **${target.tag}** has **${coins}** coins.`);
  }
};
