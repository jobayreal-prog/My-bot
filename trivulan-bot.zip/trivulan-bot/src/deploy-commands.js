// Run this once (and again any time you add/change a command) with:
//   npm run deploy-commands
require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { REST, Routes } = require("discord.js");

const commandsRoot = path.join(__dirname, "commands");
const commands = [];

for (const folder of fs.readdirSync(commandsRoot)) {
  const dir = path.join(commandsRoot, folder);
  if (!fs.statSync(dir).isDirectory()) continue;
  for (const file of fs.readdirSync(dir).filter((f) => f.endsWith(".js"))) {
    commands.push(require(path.join(dir, file)).data.toJSON());
  }
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`Registering ${commands.length} slash commands...`);
    await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands });
    console.log("Done! Global commands can take up to an hour to show up everywhere the first time.");
  } catch (err) {
    console.error(err);
  }
})();
