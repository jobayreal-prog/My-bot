require("dotenv").config();
const fs = require("fs");
const path = require("path");
const express = require("express");
const { Client, GatewayIntentBits, Collection, Partials } = require("discord.js");

const commandsRoot = path.join(__dirname, "commands");
const eventsPath = path.join(__dirname, "events");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User]
});

// ---------- Load every command from every subfolder in src/commands ----------

client.commands = new Collection();
for (const folder of fs.readdirSync(commandsRoot)) {
  const dir = path.join(commandsRoot, folder);
  if (!fs.statSync(dir).isDirectory()) continue;
  for (const file of fs.readdirSync(dir).filter((f) => f.endsWith(".js"))) {
    const command = require(path.join(dir, file));
    client.commands.set(command.data.name, command);
  }
}

// ---------- Load every event ----------

for (const file of fs.readdirSync(eventsPath).filter((f) => f.endsWith(".js"))) {
  const event = require(path.join(eventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args));
  } else {
    client.on(event.name, (...args) => event.execute(...args));
  }
}

client.login(process.env.DISCORD_TOKEN);

// ---------- Web server (simple landing page) ----------

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "public")));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`🌐 Website listening on port ${port}`));
