const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require("discord.js");
const db = require("../db");

async function handleTicketOpen(interaction) {
  const settings = db.getGuild(interaction.guild.id);

  // One open ticket per person at a time.
  const alreadyOpen = Object.entries(settings.tickets.openTickets).find(([, userId]) => userId === interaction.user.id);
  if (alreadyOpen) {
    return interaction.reply({ content: `You already have an open ticket: <#${alreadyOpen[0]}>`, ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  const overwrites = [
    { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
    { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }
  ];
  if (settings.tickets.supportRoleId) {
    overwrites.push({
      id: settings.tickets.supportRoleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
    });
  }

  const channel = await interaction.guild.channels
    .create({
      name: `ticket-${interaction.user.username}`.slice(0, 90),
      type: ChannelType.GuildText,
      permissionOverwrites: overwrites
    })
    .catch(() => null);

  if (!channel) {
    return interaction.editReply("Couldn't create a ticket channel - check my Manage Channels permission.");
  }

  db.openTicket(interaction.guild.id, channel.id, interaction.user.id);

  const closeRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket_close").setLabel("Close Ticket").setStyle(ButtonStyle.Danger).setEmoji("🔒")
  );

  await channel.send({
    content: `${interaction.user} welcome to your ticket${settings.tickets.supportRoleId ? ` - <@&${settings.tickets.supportRoleId}> will be with you shortly.` : "."}`,
    components: [closeRow]
  });

  await interaction.editReply(`Ticket opened: ${channel}`);
}

async function handleTicketClose(interaction) {
  const ownerId = db.getTicketOwner(interaction.guild.id, interaction.channel.id);
  if (!ownerId) {
    return interaction.reply({ content: "This doesn't look like an open ticket channel.", ephemeral: true });
  }

  await interaction.reply("Closing this ticket in 5 seconds...");
  db.closeTicket(interaction.guild.id, interaction.channel.id);
  setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
}

module.exports = {
  name: "interactionCreate",
  once: false,
  async execute(interaction) {
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction);
      } catch (err) {
        console.error(`Error running /${interaction.commandName}:`, err);
        const payload = { content: "Something went wrong running that command.", ephemeral: true };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(payload).catch(() => {});
        } else {
          await interaction.reply(payload).catch(() => {});
        }
      }
      return;
    }

    if (interaction.isButton()) {
      try {
        if (interaction.customId === "ticket_open") return await handleTicketOpen(interaction);
        if (interaction.customId === "ticket_close") return await handleTicketClose(interaction);
        // Buttons for /rps and /trivia are handled by their own per-message
        // collectors set up in those command files, so nothing to do here.
      } catch (err) {
        console.error("Error handling button interaction:", err);
      }
    }
  }
};
