const db = require("../db");

function fillTemplate(template, user, guild) {
  return template
    .replaceAll("{user}", user.tag)
    .replaceAll("{username}", user.username)
    .replaceAll("{server}", guild.name)
    .replaceAll("{membercount}", String(guild.memberCount));
}

module.exports = {
  name: "guildMemberRemove",
  once: false,
  async execute(member) {
    const settings = db.getGuild(member.guild.id);
    if (!settings.goodbye.channelId || !settings.goodbye.message) return;

    const channel = await member.guild.channels.fetch(settings.goodbye.channelId).catch(() => null);
    if (!channel?.isTextBased()) return;

    await channel.send(fillTemplate(settings.goodbye.message, member.user, member.guild)).catch(() => {});
  }
};
