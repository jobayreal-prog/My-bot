const { PermissionFlagsBits, EmbedBuilder } = require("discord.js");
const db = require("../db");
const { DEFAULT_BANNED_WORDS, INVITE_LINK_REGEX } = require("../automod-defaults");
const { logToModChannel } = require("../modlog");

// Simple in-memory spam tracker: guildId:userId -> array of timestamps.
// Resets if the bot restarts, which is fine for catching bursts in real time.
const recentMessages = new Map();
const SPAM_WINDOW_MS = 6000;
const SPAM_MAX_MESSAGES = 6;

function isSpamming(key) {
  const now = Date.now();
  const times = (recentMessages.get(key) || []).filter((t) => now - t < SPAM_WINDOW_MS);
  times.push(now);
  recentMessages.set(key, times);
  return times.length > SPAM_MAX_MESSAGES;
}

// XP cooldown so people can't spam-farm levels - one XP tick per 60s per user.
const xpCooldowns = new Map();
const XP_COOLDOWN_MS = 60 * 1000;

function onXpCooldown(key) {
  const last = xpCooldowns.get(key);
  const now = Date.now();
  if (last && now - last < XP_COOLDOWN_MS) return true;
  xpCooldowns.set(key, now);
  return false;
}

module.exports = {
  name: "messageCreate",
  once: false,
  async execute(message) {
    if (message.author.bot || !message.guild) return;

    // --- XP / leveling (applies to everyone, including mods) ---
    const xpKey = `${message.guild.id}:${message.author.id}`;
    if (!onXpCooldown(xpKey)) {
      const gained = 15 + Math.floor(Math.random() * 11); // 15-25
      const { level, leveledUp } = db.addXp(message.guild.id, message.author.id, gained);
      if (leveledUp) {
        const embed = new EmbedBuilder()
          .setColor(0xe3b341)
          .setDescription(`🎉 ${message.author} leveled up to **level ${level}**!`);
        await message.channel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    // Don't moderate people who can already manage messages - usually mods/admins.
    if (message.member?.permissions.has(PermissionFlagsBits.ManageMessages)) return;

    const settings = db.getGuild(message.guild.id);
    const content = message.content.toLowerCase();

    // --- Invite link filter ---
    if (INVITE_LINK_REGEX.test(content)) {
      await message.delete().catch(() => {});
      await logToModChannel(message.guild, `🔗 Removed an invite link from ${message.author.tag} in #${message.channel.name}`);
      return;
    }

    // --- Banned word filter (default list + any custom words the server added) ---
    const wordList = [...DEFAULT_BANNED_WORDS, ...settings.customBannedWords];
    if (wordList.some((word) => content.includes(word))) {
      await message.delete().catch(() => {});
      await logToModChannel(message.guild, `🚫 Removed a message from ${message.author.tag} in #${message.channel.name} (banned word)`);
      return;
    }

    // --- Spam filter ---
    const key = `${message.guild.id}:${message.author.id}`;
    if (isSpamming(key)) {
      const member = await message.guild.members.fetch(message.author.id).catch(() => null);
      if (member?.moderatable) {
        await member.timeout(5 * 60 * 1000, "Auto-timeout: message spam").catch(() => {});
        await message.channel.send(`🔇 ${message.author} was timed out for 5 minutes for spamming.`).catch(() => {});
        await logToModChannel(message.guild, `🔇 Auto-timed-out ${message.author.tag} for spam in #${message.channel.name}`);
      }
    }
  }
};
