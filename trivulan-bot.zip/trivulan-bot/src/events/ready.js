module.exports = {
  name: "ready",
  once: true,
  execute(client) {
    console.log(`✅ Trivulan is online as ${client.user.tag}`);
    client.user.setActivity("over your server | /rank", { type: 3 }); // 3 = Watching
  }
};
