const { EmbedBuilder } = require("discord.js");
const db = require("../db");

const STAR_EMOJI = "⭐";

module.exports = {
  name: "messageReactionAdd",
  once: false,
  async execute(reaction, user) {
    if (user.bot) return;
    if (reaction.emoji.name !== STAR_EMOJI) return;

    // Reactions on uncached (old) messages arrive as partials - fetch first.
    if (reaction.partial) {
      reaction = await reaction.fetch().catch(() => null);
      if (!reaction) return;
    }
    if (reaction.message.partial) {
      await reaction.message.fetch().catch(() => {});
    }

    const message = reaction.message;
    if (!message.guild) return;

    const settings = db.getGuild(message.guild.id);
    if (!settings.starboard.channelId) return;
    if (reaction.count < settings.starboard.threshold) return;
    if (message.channel.id === settings.starboard.channelId) return; // don't star the starboard itself

    const starboardChannel = await message.guild.channels.fetch(settings.starboard.channelId).catch(() => null);
    if (!starboardChannel?.isTextBased()) return;

    const existingId = db.getStarboardPost(message.guild.id, message.id);

    const embed = new EmbedBuilder()
      .setColor(0xe3b341)
      .setAuthor({ name: message.author?.tag || "Unknown user", iconURL: message.author?.displayAvatarURL?.() })
      .setDescription(message.content || "*(no text content)*")
      .addFields({ name: "Source", value: `[Jump to message](${message.url})` })
      .setTimestamp(message.createdAt);

    if (message.attachments.size > 0) {
      const firstImage = message.attachments.find((a) => a.contentType?.startsWith("image/"));
      if (firstImage) embed.setImage(firstImage.url);
    }

    const content = `${STAR_EMOJI} **${reaction.count}** - <#${message.channel.id}>`;

    if (existingId) {
      const existingMessage = await starboardChannel.messages.fetch(existingId).catch(() => null);
      if (existingMessage) {
        await existingMessage.edit({ content, embeds: [embed] }).catch(() => {});
        return;
      }
    }

    const posted = await starboardChannel.send({ content, embeds: [embed] }).catch(() => null);
    if (posted) db.setStarboardPost(message.guild.id, message.id, posted.id);
  }
};
