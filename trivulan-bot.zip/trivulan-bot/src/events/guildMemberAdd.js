const db = require("../db");
const { logToModChannel } = require("../modlog");

// Tracks recent joins per guild in memory to spot a burst of new accounts.
const recentJoins = new Map();
const JOIN_WINDOW_MS = 10000;
const JOIN_BURST_THRESHOLD = 5;
const NEW_ACCOUNT_AGE_MS = 1000 * 60 * 60 * 24 * 3; // 3 days

function fillTemplate(template, member) {
  return template
    .replaceAll("{user}", `${member}`)
    .replaceAll("{username}", member.user.username)
    .replaceAll("{server}", member.guild.name)
    .replaceAll("{membercount}", String(member.guild.memberCount));
}

module.exports = {
  name: "guildMemberAdd",
  once: false,
  async execute(member) {
    const settings = db.getGuild(member.guild.id);

    // --- Anti-raid: kick brand-new accounts joining in a rapid burst ---
    if (settings.antiRaid) {
      const now = Date.now();
      const joins = (recentJoins.get(member.guild.id) || []).filter((t) => now - t < JOIN_WINDOW_MS);
      joins.push(now);
      recentJoins.set(member.guild.id, joins);

      const isNewAccount = now - member.user.createdTimestamp < NEW_ACCOUNT_AGE_MS;
      const isBurst = joins.length > JOIN_BURST_THRESHOLD;

      if (isBurst && isNewAccount) {
        await member.kick("Anti-raid: rapid join burst + new account").catch(() => {});
        await logToModChannel(
          member.guild,
          `🛡️ Anti-raid kicked ${member.user.tag} (account created ${new Date(member.user.createdTimestamp).toLocaleDateString()}) during a join burst`
        );
        return; // don't auto-role or welcome someone who just got kicked
      }
    }

    // --- Auto-role ---
    if (settings.autoRoleId) {
      await member.roles.add(settings.autoRoleId).catch(() => {});
    }

    // --- Welcome message ---
    if (settings.welcome.channelId && settings.welcome.message) {
      const channel = await member.guild.channels.fetch(settings.welcome.channelId).catch(() => null);
      if (channel?.isTextBased()) {
        await channel.send(fillTemplate(settings.welcome.message, member)).catch(() => {});
      }
    }
  }
};
