# Trivulan

**Invite link:** https://discord.com/oauth2/authorize?client_id=1542054697408659527
**Support server:** https://discord.gg/pECMGBdTud

A free Discord moderation & security bot with everything built in: no
premium tier, no paywall. This README assumes you've never coded before
and you're doing this from an iPhone — every step is a tap, not a
terminal command.

## What Trivulan does

**Moderation**
- `/kick`, `/ban`, `/timeout`, `/warn`, `/warnings`, `/clearwarns`, `/purge`
- Invite-link filter, default + custom banned-word filter, spam auto-timeout
- `/antiraid` - kicks brand-new accounts joining in a burst
- `/warnthreshold` - auto-timeout once a member hits N warnings
- `/modlog` - mirrors moderation events into a channel you choose
- `/lockdown` - locks the current channel for @everyone

**Community**
- `/welcome` / `/goodbye` - custom join/leave messages with placeholders
  (`{user}`, `{username}`, `{server}`, `{membercount}`)
- `/autorole` - automatically gives new members a role
- `/rank` and `/leaderboard` - a leveling system based on chat activity
- `/starboard setup` - react with ⭐ enough times and a message gets
  reposted to a starboard channel
- `/ticket setup` and `/ticket panel` - posts a button that opens a
  private support channel for whoever clicks it
- `/setname` - give the bot a custom nickname in your server

**Games**
- `/8ball`, `/roll`, `/coinflip`, `/rps`, `/trivia`
- `/daily` and `/gamble` - a small coin economy, `/balance` to check it

---

## ⚠️ A note on bot tokens

A Discord bot token is like a password for that bot. Never paste it
anywhere except Railway's **Variables** tab, and never upload it in a
`.env` file to GitHub. If a token is ever exposed anywhere else, reset it
immediately from the Developer Portal (**Bot → Reset Token**).

---

## Part 1 — Create the Discord bot

1. Go to https://discord.com/developers/applications and log in.
2. **New Application**, name it **Trivulan**.
3. **Bot** tab → **Reset Token** → copy it. This is `DISCORD_TOKEN`.
4. Still on **Bot**, turn ON **Server Members Intent** and **Message
   Content Intent**.
5. **OAuth2 → General** → copy the **Client ID**. This is
   `DISCORD_CLIENT_ID`.

## Part 2 — Put the code on GitHub

1. Get the GitHub app (or use github.com in Safari) and create a free
   account if needed.
2. **New repository** → name it `trivulan-bot` → keep it private → create
   it empty.
3. Use **"Add file" → "Upload files"** to upload everything from the
   `trivulan-bot` folder, keeping the same structure (`src/`, `public/`,
   etc.). **Do not upload a `.env` file.**
4. Commit.

## Part 3 — Deploy on Railway

1. Go to https://railway.app and sign up.
2. **New Project → Deploy from GitHub repo** → pick `trivulan-bot`.
3. Open the **Variables** tab and add:
   - `DISCORD_TOKEN`
   - `DISCORD_CLIENT_ID`
   - `PUBLIC_URL` — set this after Part 4 gives you a domain
4. **Settings → Networking → Generate Domain**, then set `PUBLIC_URL` to
   that URL in Variables.
5. Once the deploy is "Active", Trivulan should show as **online** in
   Discord and your site is live at the Railway URL.

## Part 4 — Register the slash commands (one-time)

In Railway, find the option to **run a one-off command** for your
service and run:

```
npm run deploy-commands
```

Run it again any time you add a new command. If your plan doesn't offer
a one-off command runner, do this from any computer you have brief
access to: `npm install`, then `npm run deploy-commands` with the same
`.env` values.

## Part 5 — Invite Trivulan

The invite link is already set at the top of this README and baked into
the website (`public/script.js`), using your real Client ID:
`1542054697408659527`. Just open the invite link in Safari and add it to
a server. If you ever need to regenerate it (e.g. different permissions),
use Developer Portal → your application → **OAuth2 → URL Generator**
with scopes `bot`, `applications.commands` and these bot permissions:
Kick Members, Ban Members, Moderate Members, Manage Messages, Manage
Channels, Manage Roles, Change Nickname, Read Message History, Send
Messages, View Channels.

One permissions note: for `/autorole` to work, Trivulan's role needs to sit
**above** the role it's assigning, in your server's Role list (Server
Settings → Roles).

## Using it

Run any command in Discord to configure a feature - most are one-time
setup (`/welcome channel`, `/autorole`, `/starboard setup`, `/ticket
setup`), and everything else (moderation, games, leveling) just works
once the bot is in your server.

## A note on the built-in word filter

`src/automod-defaults.js` ships with a short default list of slurs so new
servers aren't unprotected on day one. Extend it per-server with
`/automod addword`, or edit the file directly for a permanent change.

## Storage note

Server settings, warnings, levels, and coins all live in `data/db.json`,
a plain file — no database setup required. On most Railway plans this
survives restarts but resets on a full redeploy. If you outgrow this,
look into a Railway **Volume** mounted at `/app/data`, or migrating to a
real database later.

## Local testing (optional)

If you ever get access to a computer: `npm install`, fill in a `.env`
file from `.env.example`, then `npm run deploy-commands` once and `npm
start` to run it locally.
