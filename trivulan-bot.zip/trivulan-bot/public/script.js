// Small tactile touch on the hero badge - toggles the anti-raid/leveling
// indicators just for visual interest, no real state behind it.
const badgeCard = document.getElementById("badge-card");
const antiraidValue = document.getElementById("badge-antiraid");
const levelingValue = document.getElementById("badge-leveling");

function toggleBadge() {
  const nowOff = antiraidValue.textContent === "ACTIVE";
  antiraidValue.textContent = nowOff ? "STANDBY" : "ACTIVE";
  levelingValue.textContent = nowOff ? "STANDBY" : "ACTIVE";
  badgeCard.setAttribute("aria-pressed", String(!nowOff));
}

badgeCard.addEventListener("click", toggleBadge);
badgeCard.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    toggleBadge();
  }
});

const TRIVULAN_INVITE =
  "https://discord.com/oauth2/authorize?client_id=1542054697408659527&scope=bot%20applications.commands&permissions=1099511686214";
const SUPPORT_SERVER = "https://discord.gg/pECMGBdTud";

document.getElementById("invite-btn").href = TRIVULAN_INVITE;
document.getElementById("invite-btn-top").href = TRIVULAN_INVITE;

const supportLink = document.getElementById("support-btn");
if (supportLink) supportLink.href = SUPPORT_SERVER;
